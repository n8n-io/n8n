/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable import/no-default-export */
declare module 'curlconverter' {
	export function toJsonString(data: string): string;
}
