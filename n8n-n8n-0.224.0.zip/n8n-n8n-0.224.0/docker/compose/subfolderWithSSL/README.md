# n8n on Subfolder with SSL

Starts n8n and deploys it on a subfolder

## Start

To start n8n in a subfolder simply start docker-compose by executing the following
command in the current folder.

**IMPORTANT:** But before you do that change the default users and passwords in the `.env` file!

```
docker-compose up -d
```

To stop it execute:

```
docker-compose stop
```
